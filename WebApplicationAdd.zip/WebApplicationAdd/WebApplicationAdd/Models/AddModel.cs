﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;


namespace WebApplicationAdd.Models
{
    public class AddModel
    {
        [Required]
        public int number1 { get; set; }
        [Required]
        public int number2 { get; set; }

        public int result { get; set; }
    }
}